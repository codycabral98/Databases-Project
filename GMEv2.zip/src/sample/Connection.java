package sample;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;


public class Connection {
    private static  String HDB = "mydb";
    private static String IP = "192.168.1.103";//database IP
    private static final String DEFAULT_BLOCK_URL = "jdbc:mysql://"+IP+":3306/"+ HDB;
    private static  String DEFAULT_USERNAME = "harrison";
    private static  String DEFAULT_PASSWORD = "harrison";

    //statements which can be passed to server
    private static String sql,sql2,sql3;
    private static Statement st = null;
    private static ResultSet rs = null;
    private static java.sql.Connection connection = null;
    private static String[] dates;

    public static void createConnection(){
        //we will also populate the games database
            try {
                connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);
                st = connection.createStatement();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            String[] names  = {"one","two","three","four","five"};

            try{

            for(int i =0; i < 20; i++) {
                sql = "INSERT INTO Projects(PID, Name,  Genre) values ('33'+"+i+", 'GGame',  'Action');";
                st.executeUpdate(sql);
            }

            } catch (SQLException e) {
                e.printStackTrace();
            }

    }



    public static ArrayList<String> getProjectsasArray(){

        //we will also populate the games database
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }


        try{
    sql = "select * from Projects;";
    rs = st.executeQuery(sql);


        } catch (SQLException e) {
            e.printStackTrace();
        }
        String id="", game="", genre="";
        ArrayList<String> content = new ArrayList<>();
        try {

            while (rs.next()) {
                id = rs.getString("PID");
                game = rs.getString("Name");
                genre = rs.getString("Genre");
                String end = id+" "+game+" 59.99\n";
                content.add(end);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return content;
    }

    public static void DummyProjects(){
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        String[] names ={"Fury agent","Combat Woods","Kings and death","madtech","Defside"};
        String[] genre = {"Action","Strategy","Horror"};
        Random rand = new Random();
        for(int i =0; i < 25; i++){
            java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
            try{
                sql = "INSERT INTO Projects(PID, Name, ReleaseDate, Genre) values ('"+rand.nextInt(3433)+"','"+names[rand.nextInt(names.length)]+"','"+date+"' ,"+"Genre"+");";
                st.execute(sql);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


    public static String getProjectsasString(){

        //we will also populate the games database
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();

        } catch (SQLException e) {
            e.printStackTrace();
        }


        try{
            sql = "select * from Projects;";
            rs = st.executeQuery(sql);


        } catch (SQLException e) {
            e.printStackTrace();
        }
        String end="";
        String id="", game="", genre="";
        ArrayList<String> content = new ArrayList<>();
        try {

            while (rs.next()) {
                id = rs.getString("PID");
                game = rs.getString("Name");
                genre = rs.getString("Genre");
                 end = id+"|   "+game+" |   59.99\n"+end;
                content.add(end);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return end;
    }




    public static String getOwnedProjectsasString(String UID){
        System.out.println("Attempting to get projects");
        //we will also populate the games database
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);
            System.out.println("Creating statement");

            st = connection.createStatement();
            System.out.println("Created");

        } catch (SQLException e) {
            e.printStackTrace();
        }


        try{
            sql = "select * from PurchaseHistory WHERE TID = ''"+UID+";";
            rs = st.executeQuery(sql);
            System.out.println("Attempting to get Owned projects");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        String end="";
        String id="", game="", genre="";
        ArrayList<String> content = new ArrayList<>();
        try {

            while (rs.next()) {
                id = rs.getString("PID");
                game = rs.getString("Name");
                genre = rs.getString("Genre");
                end = id+"|   "+game+" |   "+genre+"\n"+end;
                content.add(end);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return end;
    }

    public void AddgameToLibrary(String UID, String PID){
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        Random rand = new Random();
         java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());


        sql = "INSERT INTO PurchaseHistory(TID, TimeOfPurchase, Price, Users_UID, Projects_PID) values ('"+rand.nextInt(3433)+"','"+date+"','59.99', '"+PID+"','"+UID+"');";
        System.out.println();
        System.out.println();
        System.out.println(sql);
        System.out.println();


        sql2 = "select * from PurchaseHistory where Users_UID = '"+PID+"';";
        System.out.println(sql2);
        try {
             st.execute(sql);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        try{
            rs = st.executeQuery(sql2);
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public void addUsers() {
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }
        String[] names = {"tom", "parth", "brian", "cody", "gus", "harrison", "will"};
        Random rand = new Random();
        sql = "insert into Users (UID, Name, age, newsletter, Email) values ('" + rand.nextInt(233) + "','" + names[rand.nextInt(5)] + "','" + rand.nextInt(24) + "','0'" + ",'aol@aol.com');";
        try {
            st.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addEmp(){
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }
        java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());

        String[] names = {"tom", "parth", "brian", "cody", "gus", "harrison", "will"};
        Random rand = new Random();
        String [] lang = {"C++","Java","Python","C"};
        sql = "insert into QA (QID, Name, Age, Pay, StartDate) values ('" + rand.nextInt(233) + "','" + names[rand.nextInt(5)] + "','" + rand.nextInt(50) + "','60,000.00'" + ",'"+date+"');";
        sql2 = "insert into Developers (EmpID, Name, computerLanguage, Age, StartDate, Salary, Email) values ('" + rand.nextInt(599)+ "','" + names[rand.nextInt(5)] + "','" + lang[rand.nextInt(3)] + "','"+rand.nextInt(59)+"','"+date+"','"+"91,000.00"+"','aol.com');";
        sql3 = "insert into Managers (MID, Name, Age, Salary, StartDate) values ('"+ rand.nextInt(233) + "','" + names[rand.nextInt(5)] + "','" + 2.00 + "','"+rand.nextInt(52229)+"','"+date+"');";




        try {
            st.execute(sql);
            st.execute(sql2);
            st.execute(sql3);
            sql = "insert into ITStaff(ITID, Name, Age, Pay, StartDate) values ('" + rand.nextInt(233) + "','" + names[rand.nextInt(5)] + "','" + rand.nextInt(50) + "','60,000.00'" + ",'"+date+"');";
            sql2 = "insert into PLANNEDPATCHES (PATCHID) values ('" + rand.nextInt(599)+ "');";
            st.execute(sql);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<String> showOwnedGames(String PID){

        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);
            System.out.println("Creating statement");

            st = connection.createStatement();
            System.out.println("Created");

        } catch (SQLException e) {
            e.printStackTrace();
        }

        sql2 = "select * from PurchaseHistory where Users_UID = '"+PID+"';";
        System.out.println(sql2);
        try {
            st.execute(sql);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        try{
            rs = st.executeQuery(sql2);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String end = "Empty";
        String id = "Empty", game = "", genre = "Empty";
        ArrayList<String> content = new ArrayList<>();
        try {

            while (rs.next()) {
                id = rs.getString(1);
                genre = rs.getString("Price");

                end = id + "|   " + game + " |   " + genre + "\n";
                content.add(end);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        return content;
    }



    public String getPIDName(String PID){
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }


        sql2 = "select * from Projects where PID = '"+PID+"';";
        System.out.println(sql2);
        try {
            st.execute(sql);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        try{
            rs = st.executeQuery(sql2);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String end = "Empty";
        String id = "Empty", game = "Empty", genre = "Empty";
        ArrayList<String> content = new ArrayList<>();
        String name="";
        try {
             name = rs.getString("Name");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return name;
    }


    public ArrayList[] getEmps(){
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        ArrayList managers=new ArrayList(), qa=new ArrayList(), developers= new ArrayList();
        sql = "select * from Managers;";
        sql2 = "select * from QA;";
        sql3 = "select * from Developers;";
        String[] sqls = {sql, sql2, sql3};

        try {
            for (int i = 0; i < sqls.length; i++) {
                rs = st.executeQuery(sqls[i]);
                String one = "", two = "", three = "", four = "";
                while (rs.next()) {
                    one = rs.getString(1);
                    two = rs.getString(2);
                    three = rs.getString(3);
                    if(i==2) {
                        four = rs.getString("Email");
                    }
                    String end = one + " |" + two + " |" + three + " |" + four;
                    switch(i){
                        case(0): managers.add(end);break;
                        case(1): qa.add(end);break;
                        case(2): developers.add(end);break;
                    }
                }
            }
            } catch(SQLException e){
                e.printStackTrace();
            }

            ArrayList[] list = {managers, developers, qa};

            return list;
    }


    public void addTicket(){
        //generate random tickets
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }
        java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());


        Random rand = new Random();

        sql = "insert into Tickets (TID, Description, Resolved, Users_UID, ITStaff_ITID, Managers_MID, PLANNEDPATCHES_PATCHID, Developers_EmpID, QA_QID) values ('" + rand.nextInt(233) + "','" + "something is broken" + "','" + 0 + "','162'" + ",'161', '195', '433', '288', '135');";




        try {
            st.execute(sql);

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    public String getTickets(){
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        sql = "Select * from Tickets;";
        String end ="Empty";

        try {
           rs = st.executeQuery(sql);


            while(rs.next()){
                String tid, desc, uid, itid, managerid, patchid, devid, qaid;

                tid = rs.getString("TID");
                desc = rs.getString("Description");
                uid  = rs.getString("Users_UID");
                itid = rs.getString("ITStaff_ITID");
                managerid = rs.getString("Managers_MID");
                patchid = rs.getString("PLANNEDPATCHES_PATCHID");
                devid = rs.getString("Developers_EmpID");
                qaid = rs.getString("QA_QID");
                end = tid + " " + desc + " "+uid+" "+itid+" "+ managerid+" "+patchid+" "+devid+" "+qaid+"\n"+end;

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return end;

    }


    public String getUsers(){
        try {
            connection = DriverManager.getConnection(DEFAULT_BLOCK_URL, DEFAULT_USERNAME, DEFAULT_PASSWORD);


            st = connection.createStatement();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        sql = "Select * from Users;";
        String end ="Empty";

        try {
            rs = st.executeQuery(sql);


            while(rs.next()){
                String UID, name, age, email;
                UID = rs.getString("UID");
                name = rs.getString("Name");
                email = rs.getString("Email");

                end = UID +" "+ name +" "+ email + "\n"+end;

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return end;

    }

}
