package sample;

import javafx.fxml.FXML;

import javafx.fxml.Initializable;

import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.net.URL;
import java.rmi.server.UID;
import java.util.ArrayList;
import java.util.ResourceBundle;


public class Controller implements Initializable{



        //### THIS SECTION IS FOR THE STORE //
        @FXML
        public TextField clearuid, cu, cp;

        @FXML
        public TextArea G;
        @FXML
        public TextArea B;
        @FXML
        public TextField PGID;
        @FXML
        public TextField CCI;
        @FXML
        public TextField CPUID;

    sample.Connection c;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

         c = new sample.Connection();
         c.addEmp();
         c.addTicket();


        setproj();
        setEmps();
        setEmpsz();
        setITUsers();
        setITEmp();
        setITTickets();
        setjects();
        setUsersPR();
        setTicketsManagement();
        setQATickets();
        setTicketsPR();
        getProjects();
    }


    public void getProjects(){
        String games = c.getProjectsasString();
        B.setText(games);
    }


    public void getOwnedProjects(){

    }

    public void buy(){
        String game, cci;
        System.out.println(PGID.getText());
        System.out.println(CCI.getText());

        game = PGID.getText();
        cci = CCI.getText();
        setG();

    }

    public void adduser(){
        c.addUsers();
    }

    public void clearUI(){

        clearuid.setText("");
        cu.setText("");
        cp.setText("");
    }

    private void setG(){
        System.out.print(CPUID.getText());
        System.out.println(CPUID.getText());
        ArrayList x = c.showOwnedGames(CPUID.getText());
        String end="\n";
        System.out.println("Attempting to print result");
        for(int i =0; i < x.size(); i++){

            end = x.get(i) +"\n"+end;
        }
        end =  "GameID | Price\n"+end;

        G.setText(end);

    }



    public void addDumyProj(){
        c.DummyProjects();
    }

    public void setEmps(){
        ArrayList[] l = c.getEmps();

        String end = "";
        for(int j =0; j < l.length; j++) {
            for (int i = 0; i < l[j].size(); i++) {
                end = l[j].get(i)+"\n"+end+"\n";
            }
        }

        emp.setText(end);
    }



    //THIS IS FOR THE MANAGER VIEW

    @FXML
    public TextArea proj;
    @FXML
    public TextArea emp;
    @FXML
    public TextArea tickets;




    private void setproj(){
        System.out.print(CPUID.getText());
        System.out.println(CPUID.getText());
        ArrayList x = c.getProjectsasArray();
        String end="\n";
        System.out.println("Attempting to print result");
        for(int i =0; i < x.size(); i++){

            end = x.get(i) +"\n"+end;
        }
        end =  "GameID | Price\n"+end;

        proj.setText(end);

    }



    //THIS IS FOR THE DEVELOPER SCREEN
    @FXML
    TextArea jects;

    @FXML
    TextArea emps;


    private void setjects(){

        ArrayList x = c.getProjectsasArray();
        String end="\n";
        System.out.println("Attempting to print result");
        for(int i =0; i < x.size(); i++){

            end = x.get(i) +"\n"+end;
        }
        end =  "GameID | Price\n"+end;

        jects.setText(end);

    }

    @FXML




    public void setEmpsz(){
        ArrayList[] l = c.getEmps();

        String end = "";
        for(int j =0; j < l.length; j++) {
            for (int i = 0; i < l[j].size(); i++) {
                end = l[j].get(i)+"\n"+end+"\n";
            }
        }

        emps.setText(end);
    }

    //THIS AREA IS FOR PR, QA AND IT

    public void setTicketsManagement(){
        String end = c.getTickets();
        tickets.setText(end);
    }
        @FXML
        TextArea prtickets;

        @FXML
        TextArea prusers;
    public void setTicketsPR(){
        String end = c.getTickets();
        prtickets.setText(end);
    }

    public void setUsersPR(){
        String users = c.getUsers();
        prusers.setText(users);
    }

        @FXML TextArea ITEmp;
        @FXML TextArea ITTickets;
        @FXML TextArea ITUsers;
        @FXML TextArea QATickets;

    public void setITUsers(){
        String users = c.getUsers();
        ITUsers.setText(users);
    }

    public void setITTickets(){
        String tickets = c.getTickets();
        ITTickets.setText(tickets);
    }

    public void setITEmp(){

        ArrayList[] l = c.getEmps();

        String end = "";
        for(int j =0; j < l.length; j++) {
            for (int i = 0; i < l[j].size(); i++) {
                end = l[j].get(i)+"\n"+end+"\n";
            }
        }
        ITEmp.setText(end);
    }


    public void setQATickets(){
        String tickets = c.getTickets();
        QATickets.setText(tickets);

    }

}
